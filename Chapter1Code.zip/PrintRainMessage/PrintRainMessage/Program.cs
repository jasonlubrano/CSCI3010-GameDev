﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintRainMessage
{
    /// <summary>
    /// Prints a rain message
    /// </summary>
    class Program
    {
        /// <summary>
        /// Prints a rain message
        /// </summary>
        /// <param name="args">command-line arguments</param>
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, world");
            Console.WriteLine("Chinese Democracy is done and it's November");
            Console.WriteLine("Is it raining?");
            Console.WriteLine();
        }
    }
}
